# NavAPI source reconstruction

This project is a clean, editable source foundation based on the supplied
`navapi-1.2Hotflix3.jar` and the directory layout in the reference image.

## Modules

- `common/` — platform-independent Java API.
- `fabric/` — Fabric mod entry point and metadata.
- `spigot/` — Spigot plugin entry point.
- `paper/` — Paper plugin entry point.
- `api-lib/` — preserved library/build-support files extracted from the supplied JAR.

## Build

Requires JDK 21 and Gradle 8.x. From this directory:

```bash
gradle :fabric:build
gradle :spigot:build
gradle :paper:build
```

Artifacts are written to each module's `build/libs/` directory. The server
modules include the `common` classes through Gradle's project dependency; do
not copy the common JAR separately.

## Minecraft version compatibility

The supplied JAR does not contain enough NavAPI implementation source to prove
that it supports every version in the requested 1.20–26.3 range. This
reconstruction is a baseline scaffold, not a verified multi-version release.
Minecraft, Fabric Loader/API, Paper API, Spigot API, mappings and Java
requirements change between releases. Update the dependency coordinates and
metadata for each target release, then compile and test that release separately.
Do not set a broad `api-version: '*'` and assume it guarantees compatibility.

The initial Gradle properties target Minecraft 1.20.1. For later versions,
select matching Fabric coordinates and matching server API coordinates. A
single artifact should only claim versions that have actually been built and
tested.

## What was recoverable from the uploaded JAR

The JAR contains Fabric metadata (`id=navapi`, version `1.2`), Bukkit/Paper
plugin descriptors pointing to `online.navapi.navapi`, and a large `api-lib/`
tree. It does not contain the original Java/Kotlin implementation for that
entry point in a normal readable source form. Therefore this project supplies
a fresh platform adapter/API skeleton; it is not a byte-for-byte recovery of
the original source or its undocumented features.
