/*
 * This file is part of fabric-loom, licensed under the MIT License (MIT).
 *
 * Copyright (c) 2025 FabricMC
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package net.fabricmc.loom.api;

import org.gradle.api.Action;
import org.gradle.api.Named;
import org.gradle.api.NamedDomainObjectContainer;
import org.gradle.api.file.DirectoryProperty;
import org.gradle.api.provider.ListProperty;
import org.gradle.api.provider.MapProperty;
import org.gradle.api.provider.Property;
import org.gradle.api.tasks.SourceSet;
import org.jetbrains.annotations.ApiStatus;

/**
 * Represents a run configuration for Minecraft, these can presented via an IDE run configuration or a Gradle task.
 *
 * <p>This is used to configure how Minecraft is run, including JVM arguments, program arguments, environment variables,
 * and the main class to run.
 */
public interface RunConfiguration extends Named {
	/**
	 * The full name of the run configuration, i.e. 'Minecraft Client'.
	 *
	 * <p>By default this is determined from the base name.
	 *
	 * <p>Note: unless the project is the root project (or {@link #getAppendProjectPathToDisplayName()} is disabled),
	 * the project path will be appended automatically, e.g. 'Minecraft Client (:some:project)'.
	 */
	Property<String> getDisplayName();

	/**
	 * Arguments for the JVM, such as system properties.
	 */
	ListProperty<String> getJvmArguments();

	/**
	 * Arguments for the program, usually Minecraft specific arguments.
	 */
	ListProperty<String> getProgramArguments();

	/**
	 * Environment variables to set when running the configuration.
	 */
	MapProperty<String, Object> getEnvironmentVars();

	/**
	 * System properties to set when running the configuration.
	 */
	MapProperty<String, String> getSystemProperties();

	/**
	 * The environment (or side) to run, usually client or server.
	 */
	Property<String> getRuntimeEnvironment();

	/**
	 * Whether to append the project path to the {@link #getDisplayName()} when {@code project} isn't the root project.
	 *
	 * <p>Warning: could produce ambiguous run config names if disabled, unless used carefully in conjunction with
	 * {@link #getDisplayName()}.
	 */
	Property<Boolean> getAppendProjectPathToDisplayName();

	/**
	 * The main class of the run configuration.
	 */
	Property<String> getMainClass();

	/**
	 * The name of the {@link SourceSet} to use for the run configuration.
	 */
	Property<String> getSourceSet();

	/**
	 * The run directory for this configuration, relative to the root project directory.
	 */
	DirectoryProperty getRunDirectory();

	/**
	 * When true a run configuration file will be generated for IDE's.
	 *
	 * <p>By default only run configs on the root project will be generated.
	 */
	Property<Boolean> getGenerateRunConfig();

	/**
	 * When true generated IDE run configurations will prefer to invoke the matching Gradle run task instead of
	 * launching the game directly, when that IDE supports such a mode.
	 *
	 * <p>For example, the {@code client} run configuration will run {@code :runClient}.
	 *
	 * <p>Changing this mode may cause an existing generated run configuration to be replaced so the IDE switches to the
	 * correct run configuration type.
	 */
	Property<Boolean> getPreferGradleTask();

	/**
	 * Group this run config under the given folder.
	 *
	 * <p>This is currently only supported on IntelliJ IDEA.
	 *
	 * @return The property used to set the config folder.
	 */
	Property<String> getIdeConfigFolder();

	/**
	 * The true entrypoint, this is usually dev launch injector.
	 * This should not be changed unless you know what you are doing.
	 */
	@ApiStatus.Experimental
	Property<String> getDevLaunchMainClass();

	default void inherit(RunConfiguration parent) {
		getJvmArguments().convention(parent.getJvmArguments());
		getProgramArguments().addAll(parent.getProgramArguments());
		getEnvironmentVars().putAll(parent.getEnvironmentVars());
		getSystemProperties().putAll(parent.getSystemProperties());
		getRuntimeEnvironment().convention(parent.getRuntimeEnvironment());
		getAppendProjectPathToDisplayName().convention(parent.getAppendProjectPathToDisplayName());
		getMainClass().convention(parent.getMainClass());
		getSourceSet().convention(parent.getSourceSet());
		getRunDirectory().convention(parent.getRunDirectory());
		getGenerateRunConfig().convention(parent.getGenerateRunConfig());
		getPreferGradleTask().convention(parent.getPreferGradleTask());
		getIdeConfigFolder().convention(parent.getIdeConfigFolder());
		getDevLaunchMainClass().convention(parent.getDevLaunchMainClass());
		getForgeTemplate().convention(parent.getForgeTemplate());
		getMods().addAll(parent.getMods());
	}

	/**
	 * Configure run config with the default client options.
	 */
	default void client() {
		getRuntimeEnvironment().set("client");
		getForgeTemplate().set("client");
	}

	/**
	 * Configure run config with the default server options.
	 */
	default void server() {
		getRuntimeEnvironment().set("server");
		getProgramArguments().add("nogui");
		getForgeTemplate().set("server");
	}

	// ===================
	//  Architectury Loom
	// ===================

	/**
	 * The Forge or NeoForge run configuration template applied to this run configuration.
	 */
	Property<String> getForgeTemplate();

	/**
	 * Configure run config with the default data options.
	 *
	 * <p>This method can only be used on Forge and NeoForge.
	 */
	default void data() {
		getRuntimeEnvironment().set("data");
		getForgeTemplate().set("data");
	}

	/**
	 * Configure run config with the default data options.
	 *
	 * <p>This method can only be used on NeoForge.
	 */
	@ApiStatus.Experimental
	default void clientData() {
		getRuntimeEnvironment().set("dataClient");
		getForgeTemplate().set("dataClient");
	}

	/**
	 * Configure run config with the default data options.
	 *
	 * <p>This method can only be used on NeoForge.
	 */
	@ApiStatus.Experimental
	default void serverData() {
		getRuntimeEnvironment().set("dataServer");
		getForgeTemplate().set("dataServer");
	}

	/**
	 * {@return a container of mod settings for this run configuration}
	 *
	 * <p>If non-empty, this container will override the
	 * {@linkplain net.fabricmc.loom.api.LoomGradleExtensionAPI#getMods global container}
	 * declared in the {@code loom} extension.
	 *
	 * <p>This method is currently only available on Forge and NeoForge.
	 */
	NamedDomainObjectContainer<ModSettings> getMods();

	/**
	 * Configures the {@linkplain #getMods mods} of this run configuration.
	 *
	 * <p>This method is currently only available on Forge.
	 */
	default void mods(Action<NamedDomainObjectContainer<ModSettings>> action) {
		action.execute(getMods());
	}
}
