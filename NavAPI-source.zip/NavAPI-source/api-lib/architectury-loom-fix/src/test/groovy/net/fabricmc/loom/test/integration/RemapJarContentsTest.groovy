/*
 * This file is part of fabric-loom, licensed under the MIT License (MIT).
 *
 * Copyright (c) 2025 FabricMC
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package net.fabricmc.loom.test.integration

import java.util.jar.JarFile
import java.util.jar.Manifest

import spock.lang.Specification
import spock.lang.Unroll

import net.fabricmc.loom.test.util.GradleProjectTestTrait
import net.fabricmc.loom.util.ZipUtils

import static net.fabricmc.loom.test.LoomTestConstants.STANDARD_TEST_VERSIONS
import static org.gradle.testkit.runner.TaskOutcome.SUCCESS

class RemapJarContentsTest extends Specification implements GradleProjectTestTrait {
	@Unroll
	def "use jar apis on remapJar and remapSourcesJar (gradle #version)"() {
		setup:
		def gradle = gradleProject(project: "remapJarContents", version: version)

		when:
		def result = gradle.run(task: "build")

		then:
		result.task(":build").outcome == SUCCESS
		ZipUtils.contains(gradle.getOutputFile('fabric-example-mod-1.0.0.jar').toPath(), 'test_file.txt')
		ZipUtils.contains(gradle.getOutputFile('fabric-example-mod-1.0.0-sources.jar').toPath(), 'test_src_file.txt')
		def manifest = readManifest(gradle.getOutputFile('fabric-example-mod-1.0.0.jar'))
		manifest.mainAttributes.getValue('Hello-World') == 'test'
		manifest.mainAttributes.getValue('Inherited-In-Remap-Jar') == '1234'
		manifest.getAttributes('fabric.mod.json').getValue('Inherited-In-Remap-Jar') == '5678'
		manifest.getAttributes('modid.mixins.json').getValue('Hello-World') == 'another test'
		manifest.getAttributes('modid.mixins.json').getValue('Inherited-In-Remap-Jar') == '9'

		where:
		version << STANDARD_TEST_VERSIONS
	}

	private static Manifest readManifest(File file) {
		return new JarFile(file).withCloseable { it.manifest }
	}
}
