/*
 * This file is part of fabric-loom, licensed under the MIT License (MIT).
 *
 * Copyright (c) 2016-2021 FabricMC
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package net.fabricmc.loom.test.unit

import groovy.namespace.QName
import groovy.xml.XmlParser
import spock.lang.Specification

import net.fabricmc.loom.util.GroovyXmlUtil

class GroovyXmlUtilTest extends Specification {
	def "getOrCreateNode finds existing node"() {
		when:
		def xmlTree = new XmlParser().parseText(text)
		def existingNode = xmlTree[innerName]
		def actualNode = GroovyXmlUtil.getOrCreateNode(xmlTree, innerName)

		then:
		existingNode.text() == actualNode.text()

		where:
		innerName          | text
		"bar"              | "<foo><bar>inner content to ensure correct</bar></foo>"
		"dependencies"     | "<project xmlns=\"http://maven.apache.org/POM/4.0.0\"><dependencies>inner content to ensure correct</dependencies></project>"
	}

	def "getOrCreateNode creates a node if needed"() {
		when:
		def xmlTree = new XmlParser().parseText(text)
		def actualNode = GroovyXmlUtil.getOrCreateNode(xmlTree, innerName)

		then:
		xmlTree[QName.valueOf(actualNode.name().toString())] != null

		where:
		innerName          | text
		"bar"              | "<foo></foo>"
		"dependencies"     | "<project xmlns=\"http://maven.apache.org/POM/4.0.0\"></project>"
	}

	def "getNode finds existing node"() {
		when:
		def xmlTree = new XmlParser().parseText(text)
		def actualNode = GroovyXmlUtil.getNode(xmlTree, innerName)

		then:
		actualNode.isPresent()

		where:
		innerName          | text
		"bar"              | "<foo><bar>inner content to ensure correct</bar></foo>"
		"dependencies"     | "<project xmlns=\"http://maven.apache.org/POM/4.0.0\"><dependencies>inner content to ensure correct</dependencies></project>"
	}
}
